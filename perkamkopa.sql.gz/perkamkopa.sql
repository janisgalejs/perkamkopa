-- Adminer 4.8.1 MySQL 5.7.38 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `test_id` bigint(20) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test_id` (`test_id`),
  CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `questions` (`id`, `test_id`, `title`) VALUES
(1,	1,	'Tests 1 Jautājums 1'),
(2,	1,	'Tests 1 Jautājums 2'),
(3,	1,	'Tests 1 Jautājums 3'),
(4,	2,	'Tests 2 Jautājums 1'),
(5,	2,	'Tests 2 Jautājums 2'),
(6,	2,	'Tests 2 Jautājums 3'),
(7,	2,	'Kāda ir zemeslodes forma?'),
(8,	2,	'Vai Jāni vajadzētu pieņemt darbā?');

DROP TABLE IF EXISTS `question_answers`;
CREATE TABLE `question_answers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `question_answers_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `question_answers` (`id`, `question_id`, `title`, `correct`) VALUES
(1,	1,	'Jautājums 1 Atbilde 1',	0),
(2,	1,	'Jautājums 1 Atbilde 2 (pareiza)',	1),
(3,	2,	'Jautājums 2 atbilde 1',	0),
(4,	2,	'Jautājums 2 atbilde 2',	0),
(5,	2,	'Jautājums 2 atbilde 3 (pareiza)',	1),
(6,	2,	'Jautājums 2 atbilde 4',	0),
(7,	3,	'Jautājums 3 atbilde 1',	0),
(8,	3,	'Jautājums 3 atbilde 2',	0),
(10,	3,	'Jautājums 3 atbilde 3 (pareiza)',	1),
(11,	4,	'Jautājums 1 Atbilde 1',	0),
(12,	4,	'Jautājums 1 Atbilde 2 (pareiza)',	1),
(13,	5,	'Jautājums 2 Atbilde 1',	0),
(14,	5,	'Jautājums 2 Atbilde 2',	0),
(15,	5,	'Jautājums 2 Atbilde 3',	0),
(16,	5,	'Jautājums 2 Atbilde 4 (pareiza)',	1),
(17,	6,	'Jautājums 3 Atbilde 1 (pareiza)',	1),
(18,	6,	'Jautājums 3 Atbilde 2',	0),
(19,	7,	'Apaļa',	1),
(20,	7,	'Plakana',	0),
(21,	8,	'Jā',	1),
(22,	8,	'Nē',	0);

DROP TABLE IF EXISTS `tests`;
CREATE TABLE `tests` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tests` (`id`, `title`) VALUES
(1,	'Tests 1'),
(2,	'Tests 2'),
(3,	'Tests 3');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `test_id` bigint(20) NOT NULL,
  `username` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `test_id` (`test_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `user_answers`;
CREATE TABLE `user_answers` (
  `user_id` bigint(20) NOT NULL,
  `question_id` bigint(20) NOT NULL,
  `question_answer_id` bigint(20) NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `question_id` (`question_id`),
  KEY `question_answer_id` (`question_answer_id`),
  CONSTRAINT `user_answers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`),
  CONSTRAINT `user_answers_ibfk_3` FOREIGN KEY (`question_answer_id`) REFERENCES `question_answers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2022-10-14 14:45:39
